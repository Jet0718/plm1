/** @odoo-module */

import { registry } from "@web/core/registry"
import { useService } from "@web/core/utils/hooks"
import { loadJS } from "@web/core/assets"

const { Component, onWillStart, useRef, onMounted } = owl

export class ChartRenderer1 extends Component {
    setup(){
        debugger
        super.setup()
        this.orm = useService('orm')
        // const partners = await  this.orm.call("issue", "_getpco_status_counts", []);
        this.chartRef = useRef("chart")
        onWillStart(async ()=>{
            await loadJS("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js")
        })
        
        const fetchPartners = async () => {
          const dataarry = await this.orm.call("issue", "_getpco_status_counts", []);
          
        };

        fetchPartners();
      

        onMounted(()=>this.renderChart())
    }
    
    renderChart(){
        new Chart(this.chartRef.el,
        {
          type: 'pie',
          data: {
            labels: [
                'New',
                'Review',
                'Approved',
                'Cancel'
              ],
              datasets: [
              {
                label: 'pco states',
                data:  dataarry,
                hoverOffset: 4
              }
            ]
          },
          options: {
            responsive: true,
            plugins: {
              legend: {
                position: 'bottom',
              },
              title: {
                display: true,
                text: this.props.title,
                position: 'bottom',
              }
            }
          },
        }
      );
    }
}

ChartRenderer1.template = "owl.ChartRenderer"
